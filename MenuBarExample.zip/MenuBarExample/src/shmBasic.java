public class shmBasic {

 public static void main (String args[]) 
    {
         System.out.println ("Hello World!");
		 f_GetAppMenus("1","2");
    }
	public static String f_GetAppMenus(String as_UserID, String as_AppID)
	{
		
		StringBuffer sbXMLMenus = new StringBuffer();
		
				sbXMLMenus.append("\n<menuitem");
				sbXMLMenus.append(" id=\"");
				sbXMLMenus.append("1");
				sbXMLMenus.append("\"");
				sbXMLMenus.append(" label=\"");
				sbXMLMenus.append("File");
				sbXMLMenus.append("\"");
				sbXMLMenus.append(">");
				sbXMLMenus.append("\n</menuitem>");
				
			//sbXMLMenus.append("</>");
		
       System.out.println ("Menu : " + sbXMLMenus.toString());
		return sbXMLMenus.toString();
		
	} /** f_GetAppMenus */

}
